import com.microsoft.sentinel.sap.RuntimeConfig
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def headers = message.getHeaders()
    String destinationName = headers.get('rfcDestinationName')
    RuntimeConfig config = new RuntimeConfig(destinationName, message)
    config.setConfiguration()
    return message
}
