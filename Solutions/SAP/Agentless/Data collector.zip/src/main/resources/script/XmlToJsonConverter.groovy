import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {
    def xml = new XmlSlurper().parse(message.getBody(InputStream))

    def jsonOutput = JsonOutput.toJson(xml.item.collect { item ->
        item.children().collectEntries { child ->
            [(child.name()): child.text()]
        }
    })

    message.setHeader("Content-Type", "application/json")
    message.setBody(jsonOutput)
    return message
}
