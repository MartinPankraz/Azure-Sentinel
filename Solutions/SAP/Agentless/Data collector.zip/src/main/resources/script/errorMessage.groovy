import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def exception = message.getProperty("CamelExceptionCaught")
    if (exception != null) {
        String errorMessage = ''
        if (exception.getClass().getCanonicalName().equals("org.apache.camel.component.ahc.AhcOperationFailedException")) {
            errorMessage = exception.getResponseBody()
        } else {
            errorMessage = exception.getMessage()
        }
        throw new Exception(errorMessage)
    } else {
        throw new Exception("An unknown error occurred.")
    }
    return message
}