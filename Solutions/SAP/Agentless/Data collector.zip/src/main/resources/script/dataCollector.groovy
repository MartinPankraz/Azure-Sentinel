import com.sap.gateway.ip.core.customdev.util.Message
import com.microsoft.sentinel.sap.AuditLogsHandler
import com.microsoft.sentinel.sap.ChangeDocsLogsHandler
import com.microsoft.sentinel.sap.RolesHandler
import com.microsoft.sentinel.sap.UserDetailsHandler

def Message processData(Message message) {

    def body = message.getBody(java.io.Reader)
    def paramatersXml = new XmlSlurper().parse(body)
    def parameters = paramatersXml.Parameter
    String tableName = parameters.@Table
    String streamName = parameters.@Stream
    message.setProperty('tableName', tableName)
    message.setProperty('streamName', streamName)

    def headers = message.getHeaders()
    String destinationName = headers.get('rfcDestinationName')
    message.setProperty('rfcDestinationName', destinationName)
    message.setProperty('endTimeUTC', headers.get('endTimeUTC'))

    def handlers = [
            'ABAPAuditLog'             : new AuditLogsHandler(message),
            'ABAPChangeDocsLog'        : new ChangeDocsLogsHandler(message),
            'ABAPUserDetails'          : new UserDetailsHandler(message),
            'ABAPAuthorizationDetails' : new RolesHandler(message)
    ]

    def handler = handlers[tableName]

    if (!handler) {
        throw new IllegalArgumentException("Unknown table: $tableName")
    }

    try {
        handler.execute()
    } catch (Exception e) {
        throw new RuntimeException("Error fetching ${tableName}: " + e.getMessage())
    }

    return message
}
